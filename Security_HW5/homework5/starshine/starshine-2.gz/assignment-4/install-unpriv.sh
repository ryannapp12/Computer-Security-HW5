#!/bin/bash

if [ $# -ne 1 ]; then
    echo "Please enter the tree name"
    exit 1
fi

mkdir "$1" "$1"/bin "$1"/mail "$1"/tmp

(umask 077; mkdir "$1"/mail/addleness "$1"/mail/analects \
    "$1"/mail/annalistic "$1"/mail/anthropomorphologically \
    "$1"/mail/blepharosphincterectomy "$1"/mail/corector \
    "$1"/mail/durwaun "$1"/mail/dysphasia "$1"/mail/encampment \
    "$1"/mail/endoscopic "$1"/mail/exilic "$1"/mail/forfend \
    "$1"/mail/gorbellied "$1"/mail/gushiness "$1"/mail/muermo \
    "$1"/mail/neckar "$1"/mail/outmate "$1"/mail/outroll \
    "$1"/mail/overrich "$1"/mail/philosophicotheological \
    "$1"/mail/pockwood "$1"/mail/polypose "$1"/mail/refluxed \
    "$1"/mail/reinsure "$1"/mail/repine "$1"/mail/scerne \
    "$1"/mail/starshine "$1"/mail/unauthoritativeness \
    "$1"/mail/unminced "$1"/mail/unrosed "$1"/mail/untranquil \
    "$1"/mail/urushinic "$1"/mail/vegetocarbonaceous \
    "$1"/mail/wamara "$1"/mail/whaledom)