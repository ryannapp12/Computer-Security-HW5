#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <dirent.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/types.h>
#include <pwd.h>
#include <sys/stat.h>

#define MAX_USERNAME_LENGTH 255

//long to support large inboxes
char *getfilename(long i, char *dest){

    int j;
    dest[5] = '\0';
    //reverse for loop
    for(j=4; j >= 0; j--){
        if(i > 0){
            dest[j] = i % 10 + '0';
            i = i / 10;
        } else {
            dest[j] = '0';
        }
    }
    return dest;
}

int main(int argc, char **args){

    //get username in lower case
    char *userTo = args[1];
    char dirbuf[512];
    char filebuf[512];
    struct passwd *namestruct;
    uid_t saveuid;
    saveuid = geteuid();
    seteuid(getuid());

    strcpy(dirbuf, "mail/");
    strcat(dirbuf, userTo);
    strcat(dirbuf, "/");

    //check that the username is valid characters

    //check that the directory exists
    DIR *dp;
    seteuid(saveuid);
    if((dp = opendir(dirbuf)) == NULL){
        seteuid(getuid());
        exit(1);
    }
    closedir(dp);
    seteuid(getuid());

    //get available file number
    long num_available = 1;
    char filename[6];
    getfilename(num_available, filename);
    strcpy(filebuf, dirbuf);
    strcat(filebuf, filename);

    int i;
    for (i = 0; i < strlen(filename); i++)
    {

        //if you get to the character length max, print out error.
        if (i == MAX_USERNAME_LENGTH)
        {
            fprintf(stderr, "Error 2: Sender username is too long\n");
            exit(1);
        }
        if ((filename[i] == '/'))
        {
            fprintf(stderr, "Error: Invalid username");
            exit(1);
        }
        if ((filename[i] == '.') && (filename[i + 1] == '.'))
        {
            fprintf(stderr, "Error 3: Wrong format for the sender username\n");
            exit(1);
        }
    }

    FILE *tmp;
    seteuid(saveuid);
    tmp = fopen(filebuf, "r");
    while (tmp != NULL)
    {
        fclose(tmp);
        seteuid(getuid());
        num_available++;
        strcpy(filebuf, dirbuf);
        strcat(filebuf, getfilename(num_available, filename));
        seteuid(saveuid);
        tmp = fopen(filebuf, "r");
    }
    tmp = fopen(filebuf, "w+");

    //write from stdin to file
    char writebuf[256];
    while(fgets(writebuf, 256, stdin) != NULL){
        fputs(writebuf, tmp);
        //if there was end of message line, abort the message. 
        if (!strcmp(writebuf, "AbortMailAbortMailErrorNoEndingPeriod\n"))
        {
            seteuid(getuid());
            fclose(tmp);
            seteuid(getuid());
            remove(filebuf);
            exit(1);
        }
    }
    namestruct = getpwnam(userTo);
    fchown(fileno(tmp), namestruct->pw_uid, namestruct->pw_gid);
    fchmod(fileno(tmp), S_IRUSR);
    fclose(tmp);
    seteuid(getuid());

    return 0;

}