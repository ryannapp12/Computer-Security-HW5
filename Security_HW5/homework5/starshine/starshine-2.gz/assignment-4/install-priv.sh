#!/bin/bash

if [ $# -ne 1 ]; then
    echo "Please enter the tree name"
    exit 1
fi

input=("addleness" "analects" "annalistic" "anthropomorphologically" "blepharosphincterectomy" "corector" "durwaun" "dysphasia" "encampment" "endoscopic" "exilic" "forfend" "gorbellied" "gushiness" "muermo" "neckar" "outmate" "outroll" "overrich" "philosophicotheological" "pockwood" "polypose" "refluxed" "reinsure" "repine" "scerne" "starshine" "unauthoritativeness" "unminced" "unrosed" "untranquil" "urushinic" "vegetocarbonaceous" "wamara" "whaledom")

for i in ${input[@]}
do
	chown $i:$i "$1"/mail/$i

done

chown root:root "$1"
chmod 755 "$1"
chown root:root "$1"/bin
chmod 755 "$1"/bin
chown root:root "$1"/mail
chmod 755 "$1"/mail
chown root:root "$1"/bin/mail-out
chown root:root "$1"/bin/mail-in
chmod 711 "$1"/bin/mail-in
chmod u+s "$1"/bin/mail-in
chmod 700 "$1"/bin/mail-out