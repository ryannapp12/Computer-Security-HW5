#include <stdio.h>
#include <string.h>
#include <ctype.h> //for lower case
#include <sys/types.h>
#include <unistd.h>
#include <dirent.h>
#include <sys/wait.h>
#include <signal.h>

#define MAX_RCPT_NUM 300
#define MAX_USERNAME_LENGTH 255

//to handle sigpipe problems when closing the file descriptors
static void sig_error(int signo){
    if(signo== SIGPIPE)
        fprintf(stderr, "One of the sends failed.\n");
}


int main()
{
    char userFrom[256];
    char userTo[MAX_RCPT_NUM][256];
    int children_pid[MAX_RCPT_NUM];
    char rcptTo[9];
    int numRcpt = 0;
    char buf[512];
    char c;
    int i = 0, j;
    int second_pass = 0;
    int pid;
    int fd[MAX_RCPT_NUM][2];
    FILE *temp[MAX_RCPT_NUM];
    char tempRcpt[256];
    int ignore;
    char tempbuf[512];
    char dirbuf[512];
    DIR *dp;
    int status = 0;

    signal(SIGPIPE, sig_error);

new_mail:

    if(!second_pass){

        fgets(buf, 512, stdin);
        
    } 

    //check that the mail from control line is correct
    if (strncmp(buf, "MAIL FROM:<", 11)) {
        fprintf(stderr, "Error 1: Control Line error. Format should be: MAIL FROM:<username>\n");
        goto next_mail;
    }
        
    //if it's correct, read in the username from buf.
    //we don't use strncpy as we have control over tempbuf and buf size
    strcpy(tempbuf, buf + 11);
    for (i = 0; tempbuf[i] != '>'; i++)
    {

        //if you get to the character length max, print out error.
        if (i == MAX_USERNAME_LENGTH) {
            fprintf(stderr, "Error 2: Sender username is too long\n");
            goto next_mail;
        }
        if(i == strlen(tempbuf)) {
            fprintf(stderr, "Error 3: Wrong format for the sender username\n");
            goto next_mail;
        }
        if ((tempbuf[i] == '/')){
            fprintf(stderr, "Error: Invalid username\n");
            goto next_mail;
        }

        if((tempbuf[i] == '.') && (tempbuf[i+1] == '.')){
            fprintf(stderr, "Error 3: Wrong format for the sender username\n");
            goto next_mail;
        }
        userFrom[i] = tolower(tempbuf[i]);
    }
    userFrom[i] = '\0';
    if (tempbuf[i+1] != '\n')
    {
        fprintf(stderr, "Error 7: Control line error.\n");
        goto next_mail;
    }

    strcpy(dirbuf, "mail/");
    //we contro buffer size, strcat safe
    strcat(dirbuf, userFrom);
    strcat(dirbuf, "/");
    if ((dp = opendir(dirbuf)) == NULL)
    {
        fprintf(stderr, "Error: The user doesn't exist\n");
        goto next_mail;
    }
    closedir(dp);

    //handle first recipient
    fread(rcptTo, sizeof(char), 8, stdin);
    rcptTo[8] = '\0';

    if (strcmp("RCPT TO:", rcptTo))
    {
        fprintf(stderr, "Error 4: Control Line error. Format should be: RCPT TO:<username>\n");
        goto next_mail;
    } 

    //get the recipient username
    c = getchar();
    if (c != '<') {
        fprintf(stderr, "Error 5: Control line Error. Format should be: RCPT TO:<username>\n");
        goto next_mail;
    }
    else
    {
        i = 0;
        numRcpt = 0;
        while ((c = getchar()) != '>')
        {
            if (i == MAX_USERNAME_LENGTH)
            {
                fprintf(stderr, "Error 6: Control line Error. Recipient's name is too long.\nThe maximum length allowed is: %d.\n", MAX_USERNAME_LENGTH);
                goto next_mail;
            }
            userTo[numRcpt][i++] = tolower(c);
        }
        userTo[numRcpt][i] = '\0';
        //printf("%s\n", userTo[numRcpt]);
        numRcpt++;
    }
    //check if there are more recipients
    if (getchar() != '\n'){
        fprintf(stderr, "Error 7: Control line error.\n");
        goto next_mail;
    }
    
    fread(rcptTo, sizeof(char), 4, stdin);
    while(!strncmp("RCPT", rcptTo, 4)){
        fread(rcptTo+4, sizeof(char), 4, stdin);
        rcptTo[8] = '\0';
        //printf("%s\n", rcptTo);

        if(strcmp("RCPT TO:", rcptTo))
        {
            fprintf(stderr, "Error 4: Control Line error. Format should be: RCPT TO:<username>\n");
            goto next_mail;
        } else {

            //get the recipient username
            c = getchar();
            if (c != '<') {
                fprintf(stderr, "Error 5: Control line Error. Format should be: RCPT TO:<username>\n");
                goto next_mail;
            }
            else
            {
                int i = 0;
                while ((c = getchar()) != '>')
                {
                    if (i == MAX_USERNAME_LENGTH)
                    {
                        fprintf(stderr, "Error 6: Control line Error. Recipient's name is too long.\nThe maximum length allowed is: %d.\n", MAX_USERNAME_LENGTH);
                        goto next_mail;
                    }
                    tempRcpt[i++] = c;
                }
                tempRcpt[i] = '\0';
                //printf("%s\n", tempRcpt);
                
                if (getchar() != '\n')
                    fprintf(stderr, "Error 7: Control line error.\n");
                fread(rcptTo, sizeof(char), 4, stdin);

                ignore = 0;
                for(i = 0; i < numRcpt; i++){

                    if(!strcmp(userTo[i],tempRcpt))
                    {
                        ignore = 1;
                    }
                }
                if(!ignore){
                    //we control the size of both buffers, so strcpy is safe
                    strcpy(userTo[numRcpt], tempRcpt);
                    numRcpt++;
                }
                

            }
        }
    }

    //check if there's data coming
    if (strncmp("DATA", rcptTo, 4))
    {
        fprintf(stderr, "Error 8: Control Line error. There should be single line with the word DATA.\n");
        goto next_mail;
    }

    //fork and call mail out

    for (i = 0; i < numRcpt; i++)
    {
        if (pipe(fd[i]) < 0)
        {
            fprintf(stderr, "Pipe error. The message from %s was not delivered. This is a system error\n", userFrom);
            goto next_mail;
        }

        if ((pid = fork()) < 0)
        {
            fprintf(stderr, "System error forking\n");
        }
        //child
        else if (pid == 0)
        {
            close(fd[i][1]);
            dup2(fd[i][0], STDIN_FILENO);
            close(fd[i][0]);
            if(execl("bin/mail-out", "mail-out", userTo[i], (char *)0)){
                fprintf(stderr, "Message failed to deliver to one of the senders due to a system error\n");
            }
        }
        children_pid[i] = pid;
    }

    for(i = 0; i < numRcpt; i++){

        close(fd[i][0]);
        temp[i] = fdopen(fd[i][1], "w");

        //write the file
        fputs("From: ", temp[i]);
        fputs(userFrom, temp[i]);
        fputs("\n", temp[i]);
        fputs("To: ", temp[i]);
        for (j = 0; j < numRcpt; j++)
        {
            fputs(userTo[j], temp[i]);
            if (j != numRcpt - 1)
                fputs(", ", temp[i]);
        }
        fputs("\n", temp[i]);
    }

    

    while ((fgets(buf, 512, stdin)) != NULL)
    {
        for(i = 0; i < numRcpt; i++){
            if (buf[0] == '.' && buf[1] == '\n')
            {
                goto end_of_file;
            } else if(buf[0] == '.'){
                {
                    if (fputs(buf+1, temp[i]) < 0)
                        fprintf(stderr, "Error writing file\n");
                }
            } else
            {
                if (fputs(buf, temp[i]) < 0)
                    fprintf(stderr, "Error writing file\n");
            }
        }
    }
    //if the final period is not present send message to abort writing to file
    //i.e delete 
    for (i = 0; i < numRcpt; i++)
    {
        fputs("\nAbortMailAbortMailErrorNoEndingPeriod\n", temp[i]);
    }

end_of_file:

    for (i = 0; i < numRcpt; i++)
    {
        fclose(temp[i]);
    }
    for (i = 0; i < numRcpt; i++)
    {
        waitpid(children_pid[i], &status, 0);
        if (status != 0)
        {
            fprintf(stderr, "Error sending to %s. Check that the username is correct.\n", userTo[i]);
        }
    }

    if (fgets(buf, 512, stdin) != NULL)
    {
        second_pass = 1;
        goto new_mail;
    }
    goto return_val;

next_mail:

    while ((fgets(buf, 512, stdin)) != NULL)
    {
        if (buf[0] == '.' && buf[1] == '\n')
        {
            second_pass = 0;
            goto new_mail;
        }

    }

return_val:
        
        return 0;
    }