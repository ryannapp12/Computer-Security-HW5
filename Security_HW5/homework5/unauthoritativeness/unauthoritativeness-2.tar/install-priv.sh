#!/bin/bash

if [ $# != 1 ]; then
    echo "Usage: sudo ./install-priv <tree_name>"
    exit 1
fi

groupadd mailer

# chown mailboxes
input=("addleness" "analects" "annalistic" "anthropomorphologically" "blepharosphincterectomy" "corector" "durwaun" "dysphasia" "encampment" "endoscopic" "exilic" "forfend" "gorbellied" "gushiness" "muermo" "neckar" "outmate" "outroll" "overrich" "philosophicotheological" "pockwood" "polypose" "refluxed" "reinsure" "repine" "scerne" "starshine" "unauthoritativeness" "unminced" "unrosed" "untranquil" "urushinic" "vegetocarbonaceous" "wamara" "whaledom")

for i in ${input[@]}
do
    chown $i $1/mail/$i
    chgrp mailer $1/mail/$i 
    chmod 770 $1/mail/$i 
done

# make me a mailbox
user=$(logname)
chgrp mailer $1/mail/$user
chown $user $1/mail/$user
chmod 770 $1/mail/$user

# make the whole tree owned by root so it can't easily be deleted
chown root $1

# make tmp folder writable by mailer
chmod g+w $1/tmp

# create a dummy user to be the owner of mail-out. for reasons
random="$(cat /dev/urandom | tr -dc 'a-zA-Z0-9' | fold -w 32 | head -n 1)"
useradd mailin 
echo -e "$random\n$random\n" | passwd mailin

# executable permissions
cd $1/bin

chown mailin mail-out

# MAIL-IN
# enable setuid bit and give user
chown mailin mail-in

# set uid bit
chmod u+s mail-in

# MAIL-OUT
# turn off r/w/x bits for others
chmod o-x mail-out
chmod o-r mail-out

# set group of mail-out
chgrp mailer mail-out

# enable setgid bit on mail-out
chmod g+s mail-out

# make sure owner can execute mail-out, but nothing else
chmod u+x mail-out
chmod u-r mail-out
chmod u-w mail-out
chmod g-r mail-out

cd ..
# change owner of tmp, mail directories to mailin
chown mailin tmp
chown mailin mail
chown mailin bin
chown mailin ../$1

# do not allow anyone else to access
chmod o-x tmp
chmod o-r tmp
chmod o-w tmp
