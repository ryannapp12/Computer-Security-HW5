#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <errno.h>
#include <time.h>

#define MAX_BOX 24
#define NUM_BOXES 35
#define LINE (MAX_BOX + 100)

char buf[LINE];
int cmp, num_recips;

/* Print to stderr and skip to next message */
void err(char *msg)
{
    fprintf(stderr, "Skipping message: [%s]\n", msg);
    if(strncmp(buf, ".\n", strlen(".\n")) == 0)
        return;
    char current, next;
    fread(&current, 1, 1, stdin);
    while (fread(&next, 1, 1, stdin) > 0) {
        //EOM
        if(current == '\n' && next == '.')
            break;

        current = next;
        
    }
    fread(&next, 1, 1, stdin);
    return;
}

/* Location of close bracket on success, 0 on failure */
int extract_mailbox(char *buf, char *mailbox)
{
    //Search for first angle bracket
    int open = 0;
    int close = 0;
    int i = 0;
    for( ; i < strlen(buf); i++){
        if(buf[i] == '<'){
            open = i+1;
            break;
        }
    }
    if(!open) // if < has not been found
        return 0;

    //Search for second angle bracket
    i = open;
    for( ; i < strlen(buf); i++){
        if(buf[i] == '>'){
            close = i;
            break;
        }
    }
    if(!close)
        return 0;

    strncpy(mailbox, buf+open, close-open);
    return close;
}

/* Returns 1 on success, 0 on failure */
int get_from(char *buf, char *from_box)
{
    char *from = "MAIL FROM:<";
    int cmp = strncmp(from, buf, strlen(from));
    if(cmp != 0)
        return 0;

    int close;
    if(!(close = extract_mailbox(buf, from_box)))
        return 0;

    // Check if there are extraneous characters on the line
    if(buf[close+1] != '\n')
        return 0;

    // Check to make sure we have the whole line
    if(buf[strlen(buf) - 1] != '\n')
        return 0;

    return close;
}

/* Returns 1 on success, 0 on failure, -1 if  */
int get_to(char *buf, char *to_box)
{
    char *to = "RCPT TO:<";
    int cmp = strncmp(to, buf, strlen(to));
    if(cmp != 0)
        return 0;
    
    int close;
    if(!(close = extract_mailbox(buf, to_box)))
        return 0;

    // Check if there are extraneous characters on the line
    // if(buf[close+1] != '\n') {
    //     return 0;
    // }

    // Check to make sure we have the whole line
    if(buf[strlen(buf) - 1] != '\n')
        return -1;
        
    return 1;
}

void write_check(int filedes, const void *buf, size_t nbyte)
{
    int ret = write(filedes, buf, nbyte);
    if (ret < nbyte) {
        perror("write failed");
        close(filedes);
        exit(1);
    }
}

void close_remove(int filedes, char *filename)
{
    close(filedes);
    remove(filename);
}

void free_recipients(char **recipients)
{
    for (int i = 0; i < num_recips; i++) {
        free(recipients[i]);
    }
    free(recipients);
}


int main(int argc, char *argv[])
{
    char *ret;
    char *from = "From: ";
    char *to = "To: ";
    char *newline = "\n";
    char *comma = ", ";
    char **recipients;
    int pid, file, rfile, r, i, rv;
    
    // This is just to generate temp file names
    srand(time(NULL)); // not cryptographically secure, I know
    r = rand() % 10000;
    
    while (!feof(stdin) && (ret = fgets(buf, LINE, stdin))) {

        num_recips = 0;

        // Open file
        r = (r + 1) % 10000;
        char filename[20] = "./tmp/";
        char tmp[5];
        sprintf(tmp, "%d", r);
        strncat(filename, tmp, strlen(tmp));

	file = open(filename, O_RDWR | O_CREAT, S_IRUSR | S_IWUSR);
        if (file < 0) {
            perror("failed to open tmpfile1");
            exit(1);
        }

        // Process MAIL FROM line
        if (!ret) {
            err("fgets returned null");
            close_remove(file, filename);
            exit(1);
        }
        
        // Verify + extract MAIL FROM line
        char in_from[MAX_BOX];
        memset(in_from, 0x00, MAX_BOX);
        if (!get_from(buf, in_from)) {
            err("Invalid MAIL FROM line");
            close_remove(file, filename);
            continue;
        }
        
        in_from[MAX_BOX-1] = '\0';

        // write FROM to file
        write_check(file, from, strlen(from));
        write_check(file, in_from, strlen(in_from));
        write_check(file, newline, strlen(newline));


        // Create tempfile for recipients things
        r = (r + 1) % 10000;
        char rfilename[20] = "./tmp/";
        char r_tmp[5];
        sprintf(r_tmp, "%d", r);
        strncat(rfilename, r_tmp, strlen(r_tmp));
        rfile = open(rfilename, O_RDWR | O_CREAT, S_IRUSR | S_IWUSR);
        if (rfile < 0) {
            perror("failed to open tmpfile2");
            close_remove(file, filename);
            exit(1);
        }

        int skip = 0;

        while (1) {
            // Read RCPT TO line
            ret = fgets(buf, LINE, stdin);
            if (!ret) {
                err("fgets returned null");
                close_remove(file, filename);
                close_remove(rfile, rfilename);
                exit(1);
            }

            if(strncmp("DATA", buf, strlen("DATA")) == 0)
                break;

            char recip[MAX_BOX];
            memset(recip, 0x0, MAX_BOX);

            // Verify + extract RCPT TO line
            int g;
            while ((g = get_to(buf, recip)) != 1) {
                if (!g) {
                    err("Invalid RCPT TO line");
                    close_remove(file, filename);
                    close_remove(rfile, rfilename);
                    skip = 1;
                    break;
                } else if (g == -1) {
                    // if this particular recip line is too long
                    continue;
                }
            }
            
            if (skip)
                break;

            // write RCPTs to file
            write_check(rfile, recip, strlen(recip));
            write_check(rfile, "\0", strlen("\0"));
            write_check(rfile, "\n", strlen("\n"));
            num_recips++;
         
        }

        if (skip)
            continue;
        
        if(strncmp("DATA\n", buf, strlen("DATA\n")) != 0) {
            err("Invalid DATA line");
            close_remove(file, filename);
            close_remove(rfile, rfilename);
            continue;
        }

        recipients = malloc(num_recips * sizeof(char *));
        if (!recipients) {
            perror("malloc failed");
            close_remove(file, filename);
            close_remove(rfile, rfilename);
            exit(1);
        }

        write_check(file, to, strlen(to));

        char recipient[MAX_BOX];
        memset(recipient, 0x00, MAX_BOX);
        FILE *r_fd = fdopen(rfile, "r");
        fseek(r_fd, 0, SEEK_SET);
        for (i = 0; i < num_recips; i++) {
            fgets(recipient, MAX_BOX+1, r_fd);

            // this is very messy but it just:
            // writes recip to file without newline
            // and stores the recip in memory without newline
            write_check(file, recipient, strlen(recipient)-1);
            *(recipients + i) = malloc(strlen(recipient)+1);
            if(!(*(recipients + i))) {
                perror("malloc failed");
                close_remove(file, filename);
                close_remove(rfile, rfilename);
                free_recipients(recipients);
                exit(1);
	    } 
            strcpy(*(recipients + i), recipient);
            (*(recipients+i))[strlen(recipient)-1] = '\0';
            write_check(file, comma, strlen(comma));
        }

        // close and remove rfile
        fclose(r_fd);
        close_remove(rfile, rfilename);

        // delete last comma
        lseek(file, -2, SEEK_CUR);
        write_check(file, newline, strlen(newline));

	// write an additional newline
	write_check(file, newline, strlen(newline));

        int x;
        char current, next, prev = 0;
        x = fread(&current, 1, 1, stdin);
        if (x < 0) {
            perror("fread failed");
            close_remove(file, filename);
            free_recipients(recipients);
            exit(1);
        }
        int eom = 0;
        int b_read = 0;
        while ((x = fread(&next, 1, 1, stdin)) > 0) {
            b_read++;
            //EOM
            if(prev == '\n' && current == '.' && next == '\n') {
                eom = 1;
                break;
            }
            // remove leading period
            if(prev == '\n' && current == '.' && next != '\n') {
                prev = current;
                current = next;
                continue;
            }

            write_check(file, &current, x);
            prev = current;
            current = next;

        }
        if (current == '.' && prev == '\n')
            eom = 1;
        
        if (b_read == 0)
            eom = 1;

        if (!eom) {
            fprintf(stderr, "Skipping message: [No ending period found]\n");
            close_remove(file, filename);
            free_recipients(recipients);
            exit(1);
        }

        // Now everything has been written to this temp file
        // For each of the recips, read from file write_check to pipe
        for (i = 0; i < num_recips; i++) {
            int fd[2];
            if (pipe(fd) == -1) {
                perror("pipe failed");
                return 1;
            }
            if ((pid = fork()) < 0) {
                perror("fork failed");
                exit(1);
            }

            if(pid == 0) { // child
                close(fd[1]);  // Close the writing end of the pipe
                close(STDIN_FILENO);  // Close the current stdin
                close(file); // Close tempfile; no longer needed
                rv = dup2(fd[0], STDIN_FILENO);
                if (rv == -1) {
                    perror("dup2 failed");
                    exit(1);
                }

                execl("bin/mail-out", "bin/mail-out", *(recipients+i), NULL);
                fprintf(stderr, "execl failed\n");
                exit(3);
            } else { // parent
                char buffer[100];
                int bytes_read, status;

                rv = lseek(file, 0, SEEK_SET);
                if (rv == -1) {
                    perror("lseek failed");
                    close(fd[0]);
                    close(fd[1]);
                    close_remove(file, filename);
                    free_recipients(recipients);
                    exit(1);
                }

                close(fd[0]);

                errno = 0;

                while ((bytes_read = read(file, buffer, sizeof(buffer))) > 0) {
                    write_check(fd[1], buffer, bytes_read);
                }
                if (errno) {
                    perror("I/O error");
                    close(fd[1]);
                    close_remove(file, filename);
                    free_recipients(recipients);
                    exit(1);
                }

                close(fd[1]);

                if (waitpid(pid, &status, 0) < 0) {
                    fprintf(stderr, "waitpid error");
                    close_remove(file, filename);
                    free_recipients(recipients);
                    return 1;
                }
                if (WEXITSTATUS(status) == 1) {
                    fprintf(stderr, "Delivery to [%s] failed. Recipient invalid.\n", *(recipients+i));
                } else if (WEXITSTATUS(status) == 2) {
                    fprintf(stderr, "Delivery to [%s] failed. File I/O error.\n", *(recipients+i));
                }
            }
            
        }

        free_recipients(recipients);
        close_remove(file, filename);

    }



    return 0;
}
