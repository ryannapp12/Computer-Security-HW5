Security Architecture

I create one additional user (mailin) and one additional group (mailer). mail-in is owned by user mailin, and
has the setuid bit turned on. mail-out is owned by user mailin, and is only executable by its owner - no one other
than mail-in can execute mail-out. mail-out is in the group mailer, and has the setgid bit enabled. All of the mailboxes are writable by this group, and by their rightful owner. Delivered mail files do technically belong to user mailin and group mailer, but their permissions are set so that others can read/write them (and their user/group cannot). This is not a problem because the only user who can even access their enclosing directory is the rightful owner.

Setup Instructions

All that you have to do in terms of setup is run `make DEST=<tree_name> install`. This command assumes that
the directory tree_name does not exist, and will exit if it does.

mail-in and mail-out must be run from the top-level directory of the tree, i.e. bin/mail-in <00001.
