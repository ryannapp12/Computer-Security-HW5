#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include <dirent.h>
#include <sys/stat.h>
#include <pwd.h>

#define NO_BOXES 35
#define MAX_BOX 24

const char *mailboxes[NO_BOXES];
/* Returns 1 on success, 0 on failure */
int is_mailbox(char *mailbox)
{

    DIR *dir;
    struct dirent *ent;
    int i = 0;

    if ((dir = opendir("./mail/")) != NULL) {
        while ((ent = readdir(dir)) != NULL) {
            if(strstr(ent->d_name, ".") != NULL)
                continue;
            mailboxes[i++] = ent->d_name;
        }
        closedir (dir);
    } else {
        perror("could not open directory");
        return EXIT_FAILURE;
    }

    for (i = 0; i < NO_BOXES; i++) {
        int cmp = strncmp(mailboxes[i], mailbox, strlen(mailbox));
        if (cmp == 0)
            return 1;
    }
    return 0;
}

/* Returns 0, or -1 on error */
int number(char *d, char *file) {
    DIR *dir;
    struct dirent *ent;

    int filename = 0;

    if ((dir = opendir(d)) != NULL) {
        while ((ent = readdir(dir)) != NULL) {
            if(strstr(ent->d_name, ".") != NULL)
                continue;
            if(atoi(ent->d_name) > filename)
                filename = atoi(ent->d_name);
        }
        closedir (dir);
    } else {
        perror("could not open directory");
        return -1;
    }

    filename++;
    snprintf(file, 5*sizeof(int), "%05d", filename);
    return 0;

}

int main(int argc, char **argv)
{

    char buf[10000];
    char *recip = argv[1];
    ssize_t end;
    char filename[MAX_BOX + 20];
    int file, ret;
    char num[MAX_BOX];

    if(!is_mailbox(recip))
        return 1;

    memset(filename, 0x00, MAX_BOX + 20);

    strcat(filename, "./mail/");
    strcat(filename, recip);
    strcat(filename, "/");
    number(filename, num);
    strcat(filename, num);

    file = open(filename, O_RDWR | O_CREAT, S_IROTH | S_IWOTH);
    if (file < 0) {
        return 2;
    }
    fchmod(file, S_IWOTH | S_IROTH);

    while(!feof(stdin)){
        end = fread(buf, 1, 100000, stdin);
        if (end == -1) {
            close(file);
            remove(filename);
            return 2;
        }

        ret = write(file, buf, end);
        if (ret == -1) {
            close(file);
            remove(filename);
            return 2;
        }
    }

    fclose(stdin);

    return 0;
}
