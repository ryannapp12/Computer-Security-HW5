#include <dirent.h>
#include <regex.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/queue.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

#define GIGABYTE 1000000000
#define MAIL "../mail"
#define USERNAME_PREG "^[a-z]+[a-z0-9\\+\\-_]*$"
#define MAILFROM_PREG "^\\.?mail\\sfrom:<([^<>]+)>$"
#define RCPT_PREG "^\\.?rcpt\\sto:<([^<>]+)>$"
#define DATA_PREG "^\\.?data$"
#define DELIM_PREG "^\\.$"
#define MSG_PREG "^\\.?(.+)$"

// The following code block is used to free everything, which  
// I squished into one line to preserve the readability of 
// the rest of the program.
/*
free(line); 
line = NULL; 
free(sender); 
sender = NULL; 
while (!TAILQ_EMPTY(&mq)) {
  n1 = TAILQ_FIRST(&mq);
  msg = n1->datum;
  free(msg);
  msg = NULL;
  TAILQ_REMOVE(&mq, n1, tailq);
  free(n1);
  n1 = NULL;
}
while (!TAILQ_EMPTY(&rq)) {
  n1 = TAILQ_FIRST(&rq);
  rcpt = n1->datum;
  free(rcpt);
  rcpt = NULL;
  TAILQ_REMOVE(&rq, n1, tailq);
  free(n1);
  n1 = NULL;
}
*/

struct node {
  TAILQ_ENTRY(node) tailq;
  char *datum;
};

struct node *node(char *val) {
  struct node *x = (struct node *) malloc(sizeof(struct node));
  if (x == NULL) {
    fprintf(stderr, "Malloc failed.\n");
    return NULL;
  }
  x->tailq.tqe_next = NULL;
  x->tailq.tqe_prev = NULL;
  x->datum = val;
  return x;
}

int match_regex(char *pattern, char *string) {
  int match_flag = 0;
  regex_t regex_compiled;

  match_flag = regcomp(&regex_compiled, pattern, REG_EXTENDED | REG_ICASE | REG_NOSUB);

  if (match_flag == 0) {
    match_flag = regexec(&regex_compiled, string, 1, NULL, 0);
  }
  else {
    fprintf(stderr, "Regex could not compile.\n");
  }

  regfree(&regex_compiled);
  return match_flag;
}

char *capture_regex(char *pattern, char *string) {
  int comp_flag = 0, so = 0, eo = 0;
  regex_t regex_compiled;
  regmatch_t regex_groups[2];

  comp_flag = regcomp(&regex_compiled, pattern, REG_EXTENDED | REG_ICASE);
  if (comp_flag == 0) {
    if (regexec(&regex_compiled, string, 2, regex_groups, 0) == 0) {
      so = regex_groups[1].rm_so;
      eo = regex_groups[1].rm_eo;

      char *substring = malloc(eo - so + 2);
      if (substring == NULL) {
        fprintf(stderr, "Malloc failed.\n");
        return NULL;
      }
      snprintf(substring, eo - so + 1, "%s", string + so);

      regfree(&regex_compiled);
      return substring;
    }
  }
  else {
    fprintf(stderr, "Regex could not compile.\n");
  }
  regfree(&regex_compiled);
  return NULL;
}
// Check sender validity by checking access to directory 
int validate_sender(char *sender) {
  struct stat sb;
  
  // Path for "mail/<recipient>"
  char path[strlen(MAIL) + strlen(sender) + 2];
  snprintf(path, sizeof path, "%s/%s", MAIL, sender);

  return !(stat(path, &sb) == 0 && S_ISDIR(sb.st_mode));
}

int main(int argc, char **argv) {
  gid_t savegid;
  savegid = getegid();
  if (setegid(getgid()) == -1) {
    fprintf(stderr, "Privilege changing failed.\n");
    exit(1);
  }

  int rcpt_count = 0, error_flag = 0, control_flag = 0, dupe_flag = 0;
  ssize_t n_read = 0, n_written = 0;
  size_t size = 0, total_size = 0;
  char *line = NULL, *sender = NULL, *rcpt = NULL, *msg = NULL, *first_rcpt = NULL;
  int fd[2];
  pid_t p;
  struct stat statbuf;

  TAILQ_HEAD(rcpt_q, node);
  TAILQ_HEAD(msg_q, node);
  struct rcpt_q rq;
  struct msg_q mq;
  TAILQ_INIT(&rq);
  TAILQ_INIT(&mq);
  struct node *n1, *n2;

  n_read = getline(&line, &size, stdin);
  while (n_read > 0) {
    total_size += size;
    if (total_size > GIGABYTE) {
      free(line); line = NULL; free(sender); sender = NULL; while (!TAILQ_EMPTY(&mq)) { n1 = TAILQ_FIRST(&mq); msg = n1->datum; free(msg); msg = NULL; TAILQ_REMOVE(&mq, n1, tailq); free(n1); n1 = NULL; } while (!TAILQ_EMPTY(&rq)) { n1 = TAILQ_FIRST(&rq); rcpt = n1->datum; free(rcpt); rcpt = NULL; TAILQ_REMOVE(&rq, n1, tailq); free(n1); n1 = NULL; }
      fprintf(stderr, "File size exceeds 1 GB.\n");
      exit(1);
    }

    if ((line)[n_read - 1] == '\n') {
      (line)[n_read - 1] = '\0';
      --n_read;
    }

    // 5. Check if next line matches DELIM_PREG
    //      Send message if error_flag == 0
    //      Reset all msg-specific flags and counts
    if (match_regex(DELIM_PREG, line) == 0) {
      if (!error_flag && !control_flag && sender != NULL) {
        TAILQ_FOREACH(n1, &rq, tailq) {
          if (pipe(fd) == -1) {
            fprintf(stderr, "Pipe failed.\n");
            free(line); line = NULL; free(sender); sender = NULL; while (!TAILQ_EMPTY(&mq)) { n1 = TAILQ_FIRST(&mq); msg = n1->datum; free(msg); msg = NULL; TAILQ_REMOVE(&mq, n1, tailq); free(n1); n1 = NULL; } while (!TAILQ_EMPTY(&rq)) { n1 = TAILQ_FIRST(&rq); rcpt = n1->datum; free(rcpt); rcpt = NULL; TAILQ_REMOVE(&rq, n1, tailq); free(n1); n1 = NULL; }
            exit(1);
          }

          p = fork();
          if (p < 0) {
            fprintf(stderr, "Fork failed.\n");
            free(line); line = NULL; free(sender); sender = NULL; while (!TAILQ_EMPTY(&mq)) { n1 = TAILQ_FIRST(&mq); msg = n1->datum; free(msg); msg = NULL; TAILQ_REMOVE(&mq, n1, tailq); free(n1); n1 = NULL; } while (!TAILQ_EMPTY(&rq)) { n1 = TAILQ_FIRST(&rq); rcpt = n1->datum; free(rcpt); rcpt = NULL; TAILQ_REMOVE(&rq, n1, tailq); free(n1); n1 = NULL; }
            exit(1);
          }
          else if (p == 0) {
            // Child process
            if (close(fd[1]) == -1) {
              fprintf(stderr, "Close failed.\n");
              free(line); line = NULL; free(sender); sender = NULL; while (!TAILQ_EMPTY(&mq)) { n1 = TAILQ_FIRST(&mq); msg = n1->datum; free(msg); msg = NULL; TAILQ_REMOVE(&mq, n1, tailq); free(n1); n1 = NULL; } while (!TAILQ_EMPTY(&rq)) { n1 = TAILQ_FIRST(&rq); rcpt = n1->datum; free(rcpt); rcpt = NULL; TAILQ_REMOVE(&rq, n1, tailq); free(n1); n1 = NULL; }
              exit(1);
            }
            if (close(STDIN_FILENO) == -1) {
              fprintf(stderr, "Close failed.\n");
              free(line); line = NULL; free(sender); sender = NULL; while (!TAILQ_EMPTY(&mq)) { n1 = TAILQ_FIRST(&mq); msg = n1->datum; free(msg); msg = NULL; TAILQ_REMOVE(&mq, n1, tailq); free(n1); n1 = NULL; } while (!TAILQ_EMPTY(&rq)) { n1 = TAILQ_FIRST(&rq); rcpt = n1->datum; free(rcpt); rcpt = NULL; TAILQ_REMOVE(&rq, n1, tailq); free(n1); n1 = NULL; }
              exit(1);
            }
            if (dup2(fd[0], STDIN_FILENO) == -1) {
              fprintf(stderr, "Dup2 failed.\n");
              free(line); line = NULL; free(sender); sender = NULL; while (!TAILQ_EMPTY(&mq)) { n1 = TAILQ_FIRST(&mq); msg = n1->datum; free(msg); msg = NULL; TAILQ_REMOVE(&mq, n1, tailq); free(n1); n1 = NULL; } while (!TAILQ_EMPTY(&rq)) { n1 = TAILQ_FIRST(&rq); rcpt = n1->datum; free(rcpt); rcpt = NULL; TAILQ_REMOVE(&rq, n1, tailq); free(n1); n1 = NULL; }
              exit(1);
            }
            if (stat("./mail-out", &statbuf) != 0) {
              fprintf(stderr, "Stat mail-out failed.\n");
              free(line); line = NULL; free(sender); sender = NULL; while (!TAILQ_EMPTY(&mq)) { n1 = TAILQ_FIRST(&mq); msg = n1->datum; free(msg); msg = NULL; TAILQ_REMOVE(&mq, n1, tailq); free(n1); n1 = NULL; } while (!TAILQ_EMPTY(&rq)) { n1 = TAILQ_FIRST(&rq); rcpt = n1->datum; free(rcpt); rcpt = NULL; TAILQ_REMOVE(&rq, n1, tailq); free(n1); n1 = NULL; }
              exit(1);
            }
            if (statbuf.st_gid != savegid) {
              fprintf(stderr, "Illegal mail-out program.\n");
              free(line); line = NULL; free(sender); sender = NULL; while (!TAILQ_EMPTY(&mq)) { n1 = TAILQ_FIRST(&mq); msg = n1->datum; free(msg); msg = NULL; TAILQ_REMOVE(&mq, n1, tailq); free(n1); n1 = NULL; } while (!TAILQ_EMPTY(&rq)) { n1 = TAILQ_FIRST(&rq); rcpt = n1->datum; free(rcpt); rcpt = NULL; TAILQ_REMOVE(&rq, n1, tailq); free(n1); n1 = NULL; }
              exit(1);
            }
            if (setegid(savegid) == -1) {
              fprintf(stderr, "Privilege changing failed.\n");
              free(line); line = NULL; free(sender); sender = NULL; while (!TAILQ_EMPTY(&mq)) { n1 = TAILQ_FIRST(&mq); msg = n1->datum; free(msg); msg = NULL; TAILQ_REMOVE(&mq, n1, tailq); free(n1); n1 = NULL; } while (!TAILQ_EMPTY(&rq)) { n1 = TAILQ_FIRST(&rq); rcpt = n1->datum; free(rcpt); rcpt = NULL; TAILQ_REMOVE(&rq, n1, tailq); free(n1); n1 = NULL; }
              exit(1);
            }
            if (execl("./mail-out", "./mail-out", n1->datum, NULL) == -1) {
              setegid(getgid());
              fprintf(stderr, "Execl failed.\n");
              free(line); line = NULL; free(sender); sender = NULL; while (!TAILQ_EMPTY(&mq)) { n1 = TAILQ_FIRST(&mq); msg = n1->datum; free(msg); msg = NULL; TAILQ_REMOVE(&mq, n1, tailq); free(n1); n1 = NULL; } while (!TAILQ_EMPTY(&rq)) { n1 = TAILQ_FIRST(&rq); rcpt = n1->datum; free(rcpt); rcpt = NULL; TAILQ_REMOVE(&rq, n1, tailq); free(n1); n1 = NULL; }
              exit(1);
            }
            if (setegid(getgid()) == -1) {
              fprintf(stderr, "Privilege changing failed.\n");
              free(line); line = NULL; free(sender); sender = NULL; while (!TAILQ_EMPTY(&mq)) { n1 = TAILQ_FIRST(&mq); msg = n1->datum; free(msg); msg = NULL; TAILQ_REMOVE(&mq, n1, tailq); free(n1); n1 = NULL; } while (!TAILQ_EMPTY(&rq)) { n1 = TAILQ_FIRST(&rq); rcpt = n1->datum; free(rcpt); rcpt = NULL; TAILQ_REMOVE(&rq, n1, tailq); free(n1); n1 = NULL; }
              exit(1);
            }
          }
          else {
            // Parent process
            int status;
            if (close(fd[0]) == -1) {
              fprintf(stderr, "Close failed.\n");
              free(line); line = NULL; free(sender); sender = NULL; while (!TAILQ_EMPTY(&mq)) { n1 = TAILQ_FIRST(&mq); msg = n1->datum; free(msg); msg = NULL; TAILQ_REMOVE(&mq, n1, tailq); free(n1); n1 = NULL; } while (!TAILQ_EMPTY(&rq)) { n1 = TAILQ_FIRST(&rq); rcpt = n1->datum; free(rcpt); rcpt = NULL; TAILQ_REMOVE(&rq, n1, tailq); free(n1); n1 = NULL; }
              exit(1);
            }

            // From: sender
            n_written = write(fd[1], "From: ", strlen("From: "));
            if (n_written < strlen("From: ")) {
              fprintf(stderr, "Error writing to stdout.\n");
              free(line); line = NULL; free(sender); sender = NULL; while (!TAILQ_EMPTY(&mq)) { n1 = TAILQ_FIRST(&mq); msg = n1->datum; free(msg); msg = NULL; TAILQ_REMOVE(&mq, n1, tailq); free(n1); n1 = NULL; } while (!TAILQ_EMPTY(&rq)) { n1 = TAILQ_FIRST(&rq); rcpt = n1->datum; free(rcpt); rcpt = NULL; TAILQ_REMOVE(&rq, n1, tailq); free(n1); n1 = NULL; }
              exit(1);
            }
            n_written = write(fd[1], sender, strlen(sender));
            if (n_written < strlen(sender)) {
              fprintf(stderr, "Error writing to stdout.\n");
              free(line); line = NULL; free(sender); sender = NULL; while (!TAILQ_EMPTY(&mq)) { n1 = TAILQ_FIRST(&mq); msg = n1->datum; free(msg); msg = NULL; TAILQ_REMOVE(&mq, n1, tailq); free(n1); n1 = NULL; } while (!TAILQ_EMPTY(&rq)) { n1 = TAILQ_FIRST(&rq); rcpt = n1->datum; free(rcpt); rcpt = NULL; TAILQ_REMOVE(&rq, n1, tailq); free(n1); n1 = NULL; }
              exit(1);
            }
            n_written = write(fd[1], "\n", strlen("\n"));
            if (n_written < strlen("\n")) {
              fprintf(stderr, "Error writing to stdout.\n");
              free(line); line = NULL; free(sender); sender = NULL; while (!TAILQ_EMPTY(&mq)) { n1 = TAILQ_FIRST(&mq); msg = n1->datum; free(msg); msg = NULL; TAILQ_REMOVE(&mq, n1, tailq); free(n1); n1 = NULL; } while (!TAILQ_EMPTY(&rq)) { n1 = TAILQ_FIRST(&rq); rcpt = n1->datum; free(rcpt); rcpt = NULL; TAILQ_REMOVE(&rq, n1, tailq); free(n1); n1 = NULL; }
              exit(1);
            }

            // To: rcpt, rcpt, ...
            n_written = write(fd[1], "To: ", strlen("To: "));
            if (n_written < strlen("To: ")) {
              fprintf(stderr, "Error writing to stdout.\n");
              free(line); line = NULL; free(sender); sender = NULL; while (!TAILQ_EMPTY(&mq)) { n1 = TAILQ_FIRST(&mq); msg = n1->datum; free(msg); msg = NULL; TAILQ_REMOVE(&mq, n1, tailq); free(n1); n1 = NULL; } while (!TAILQ_EMPTY(&rq)) { n1 = TAILQ_FIRST(&rq); rcpt = n1->datum; free(rcpt); rcpt = NULL; TAILQ_REMOVE(&rq, n1, tailq); free(n1); n1 = NULL; }
              exit(1);
            }
            n2 = TAILQ_FIRST(&rq);
            if (n2 != NULL) {
              rcpt = n2->datum;
              first_rcpt = rcpt;
              n_written = write(fd[1], rcpt, strlen(rcpt));
              if (n_written < strlen(rcpt)) {
                fprintf(stderr, "Error writing to stdout.\n");
                free(line); line = NULL; free(sender); sender = NULL; while (!TAILQ_EMPTY(&mq)) { n1 = TAILQ_FIRST(&mq); msg = n1->datum; free(msg); msg = NULL; TAILQ_REMOVE(&mq, n1, tailq); free(n1); n1 = NULL; } while (!TAILQ_EMPTY(&rq)) { n1 = TAILQ_FIRST(&rq); rcpt = n1->datum; free(rcpt); rcpt = NULL; TAILQ_REMOVE(&rq, n1, tailq); free(n1); n1 = NULL; }
                exit(1);
              }
              rcpt = NULL;
            }

            TAILQ_FOREACH(n2, &rq, tailq) {
              if (strncmp(n2->datum, first_rcpt, strlen(first_rcpt) + 1) != 0) {
                n_written = write(fd[1], ", ", strlen(", "));
                if (n_written < strlen(", ")) {
                  fprintf(stderr, "Error writing to stdout.\n");
                  free(line); line = NULL; free(sender); sender = NULL; while (!TAILQ_EMPTY(&mq)) { n1 = TAILQ_FIRST(&mq); msg = n1->datum; free(msg); msg = NULL; TAILQ_REMOVE(&mq, n1, tailq); free(n1); n1 = NULL; } while (!TAILQ_EMPTY(&rq)) { n1 = TAILQ_FIRST(&rq); rcpt = n1->datum; free(rcpt); rcpt = NULL; TAILQ_REMOVE(&rq, n1, tailq); free(n1); n1 = NULL; }
                  exit(1);
                }
                rcpt = n2->datum;
                n_written = write(fd[1], rcpt, strlen(rcpt));
                if (n_written < strlen(rcpt)) {
                  fprintf(stderr, "Error writing to stdout.\n");
                  free(line); line = NULL; free(sender); sender = NULL; while (!TAILQ_EMPTY(&mq)) { n1 = TAILQ_FIRST(&mq); msg = n1->datum; free(msg); msg = NULL; TAILQ_REMOVE(&mq, n1, tailq); free(n1); n1 = NULL; } while (!TAILQ_EMPTY(&rq)) { n1 = TAILQ_FIRST(&rq); rcpt = n1->datum; free(rcpt); rcpt = NULL; TAILQ_REMOVE(&rq, n1, tailq); free(n1); n1 = NULL; }
                  exit(1);
                }
                rcpt = NULL;
              }
            }
            n_written = write(fd[1], "\n\n", strlen("\n\n"));
            if (n_written < strlen("\n\n")) {
              fprintf(stderr, "Error writing to stdout.\n");
              free(line); line = NULL; free(sender); sender = NULL; while (!TAILQ_EMPTY(&mq)) { n1 = TAILQ_FIRST(&mq); msg = n1->datum; free(msg); msg = NULL; TAILQ_REMOVE(&mq, n1, tailq); free(n1); n1 = NULL; } while (!TAILQ_EMPTY(&rq)) { n1 = TAILQ_FIRST(&rq); rcpt = n1->datum; free(rcpt); rcpt = NULL; TAILQ_REMOVE(&rq, n1, tailq); free(n1); n1 = NULL; }
              exit(1);
            }

            // Message body
            TAILQ_FOREACH(n2, &mq, tailq) {
              msg = n2->datum;
              n_written = write(fd[1], msg, strlen(msg));
              if (n_written < strlen(msg)) {
                fprintf(stderr, "Error writing to stdout.\n");
                free(line); line = NULL; free(sender); sender = NULL; while (!TAILQ_EMPTY(&mq)) { n1 = TAILQ_FIRST(&mq); msg = n1->datum; free(msg); msg = NULL; TAILQ_REMOVE(&mq, n1, tailq); free(n1); n1 = NULL; } while (!TAILQ_EMPTY(&rq)) { n1 = TAILQ_FIRST(&rq); rcpt = n1->datum; free(rcpt); rcpt = NULL; TAILQ_REMOVE(&rq, n1, tailq); free(n1); n1 = NULL; }
                exit(1);
              }
              msg = NULL;
              n_written = write(fd[1], "\n", strlen("\n"));
              if (n_written < strlen("\n")) {
                fprintf(stderr, "Error writing to stdout.\n");
                free(line); line = NULL; free(sender); sender = NULL; while (!TAILQ_EMPTY(&mq)) { n1 = TAILQ_FIRST(&mq); msg = n1->datum; free(msg); msg = NULL; TAILQ_REMOVE(&mq, n1, tailq); free(n1); n1 = NULL; } while (!TAILQ_EMPTY(&rq)) { n1 = TAILQ_FIRST(&rq); rcpt = n1->datum; free(rcpt); rcpt = NULL; TAILQ_REMOVE(&rq, n1, tailq); free(n1); n1 = NULL; }
                exit(1);
              }
            }

            if (close(fd[1]) == -1) {
              fprintf(stderr, "Close failed.\n");
              free(line); line = NULL; free(sender); sender = NULL; while (!TAILQ_EMPTY(&mq)) { n1 = TAILQ_FIRST(&mq); msg = n1->datum; free(msg); msg = NULL; TAILQ_REMOVE(&mq, n1, tailq); free(n1); n1 = NULL; } while (!TAILQ_EMPTY(&rq)) { n1 = TAILQ_FIRST(&rq); rcpt = n1->datum; free(rcpt); rcpt = NULL; TAILQ_REMOVE(&rq, n1, tailq); free(n1); n1 = NULL; }
              exit(1);
            }
            p = wait(&status);
            // printf("Child exit status: %d\n", WEXITSTATUS(status));
          }
        }
      }

      total_size = 0;
      rcpt_count = 0;
      error_flag = 0;
      control_flag = 0;
      free(sender);
      sender = NULL;
      while (!TAILQ_EMPTY(&mq)) {
        n1 = TAILQ_FIRST(&mq);
        msg = n1->datum;
        free(msg);
        msg = NULL;
        TAILQ_REMOVE(&mq, n1, tailq);
        free(n1);
        n1 = NULL;
      }
      while (!TAILQ_EMPTY(&rq)) {
        n1 = TAILQ_FIRST(&rq);
        rcpt = n1->datum;
        free(rcpt);
        rcpt = NULL;
        TAILQ_REMOVE(&rq, n1, tailq);
        free(n1);
        n1 = NULL;
      }
    }
    // Only continue if no errors
    else if (!error_flag) {
      // 1. Check if first line matches MAILFROM_PREG and if sender is valid username and real mailbox
      //      Store sender
      if (sender == NULL) {
        sender = capture_regex(MAILFROM_PREG, line);
        if (sender != NULL && match_regex(USERNAME_PREG, sender) == 0 && validate_sender(sender) == 0) {
          control_flag = 1;
        }
        else {
          error_flag = 1;
        }
      }
      // 2. Loop: check if next line matches RCPT_PREG
      //      Store rcpt
      else if (control_flag) {
        rcpt = capture_regex(RCPT_PREG, line);
        if (rcpt != NULL) {
          // Check for duplicates
          TAILQ_FOREACH(n1, &rq, tailq) {
            if (strncmp(n1->datum, rcpt, strlen(rcpt) + 1) == 0) {
              dupe_flag = 1;
            }
          }
          if (!dupe_flag && match_regex(USERNAME_PREG, rcpt) == 0) {
            rcpt_count++;
            struct node *r = node(rcpt);
            if (r == NULL) {
              free(line); line = NULL; free(sender); sender = NULL; while (!TAILQ_EMPTY(&mq)) { n1 = TAILQ_FIRST(&mq); msg = n1->datum; free(msg); msg = NULL; TAILQ_REMOVE(&mq, n1, tailq); free(n1); n1 = NULL; } while (!TAILQ_EMPTY(&rq)) { n1 = TAILQ_FIRST(&rq); rcpt = n1->datum; free(rcpt); rcpt = NULL; TAILQ_REMOVE(&rq, n1, tailq); free(n1); n1 = NULL; } 
              exit(1);
            }
            TAILQ_INSERT_TAIL(&rq, r, tailq);
            rcpt = NULL;
          }
          else {
            dupe_flag = 0;
            free(rcpt);
            rcpt = NULL;
          }
        }
        else {
          // 3. Check if next line matches DATA_PREG and we have at least 1 rcpt
          if (rcpt_count > 0 && match_regex(DATA_PREG, line) == 0) {
            control_flag = 0;
          }
          else {
            error_flag = 1;
          }
        }
      }
      // 4. Loop: check if next line isnt DELIM_PREG
      //      Get msg with MSG_PREG and store
      else if (match_regex(DELIM_PREG, line) != 0) {
        if (line[0] == '\0') {
          msg = (char *) malloc(1);
          if (msg == NULL) {
            fprintf(stderr, "Malloc failed.\n");
            free(line); line = NULL; free(sender); sender = NULL; while (!TAILQ_EMPTY(&mq)) { n1 = TAILQ_FIRST(&mq); msg = n1->datum; free(msg); msg = NULL; TAILQ_REMOVE(&mq, n1, tailq); free(n1); n1 = NULL; } while (!TAILQ_EMPTY(&rq)) { n1 = TAILQ_FIRST(&rq); rcpt = n1->datum; free(rcpt); rcpt = NULL; TAILQ_REMOVE(&rq, n1, tailq); free(n1); n1 = NULL; }
            exit(1);
          }
          msg[0] = '\0';
        }
        else {
          msg = capture_regex(MSG_PREG, line);
        }
        
        if (msg != NULL) {
          struct node *m = node(msg);
          if (m == NULL) {
            free(line); line = NULL; free(sender); sender = NULL; while (!TAILQ_EMPTY(&mq)) { n1 = TAILQ_FIRST(&mq); msg = n1->datum; free(msg); msg = NULL; TAILQ_REMOVE(&mq, n1, tailq); free(n1); n1 = NULL; } while (!TAILQ_EMPTY(&rq)) { n1 = TAILQ_FIRST(&rq); rcpt = n1->datum; free(rcpt); rcpt = NULL; TAILQ_REMOVE(&rq, n1, tailq); free(n1); n1 = NULL; } 
            exit(1);
          }
          TAILQ_INSERT_TAIL(&mq, m, tailq);
          msg = NULL;
        }
        else {
          error_flag = 1;
        }
      }
    }
    free(line);
    line = NULL;
    n_read = getline(&line, &size, stdin);
  }
  free(line); line = NULL; free(sender); sender = NULL; while (!TAILQ_EMPTY(&mq)) { n1 = TAILQ_FIRST(&mq); msg = n1->datum; free(msg); msg = NULL; TAILQ_REMOVE(&mq, n1, tailq); free(n1); n1 = NULL; } while (!TAILQ_EMPTY(&rq)) { n1 = TAILQ_FIRST(&rq); rcpt = n1->datum; free(rcpt); rcpt = NULL; TAILQ_REMOVE(&rq, n1, tailq); free(n1); n1 = NULL; }

  exit(0);
}