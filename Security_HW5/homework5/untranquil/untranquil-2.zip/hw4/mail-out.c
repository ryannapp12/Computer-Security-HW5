#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>

#define MAIL "../mail"

void usage() {
  fprintf(stderr, "%s", "Usage: mail-out <recipient>\n");
}

// Check recipient validity by checking access to directory 
int validate_recipient(char *recipient) {
  struct stat sb;
  
  // Path for "mail/<recipient>"
  char path[strlen(MAIL) + strlen(recipient) + 2];
  snprintf(path, sizeof path, "%s/%s", MAIL, recipient);

  return !(stat(path, &sb) == 0 && S_ISDIR(sb.st_mode));
}

int main(int argc, char **argv) {
  FILE *out = NULL;
  int write = 0;
  char *line = NULL;
  size_t size = 0;
  char path[strlen(MAIL) + strlen(argv[1]) + 8];
  struct stat statbuf;   
  int n;

  if (argc == 2) {
    if (validate_recipient(argv[1]) == 0) {
      for (n = 1; n <= 99999; n++) {
        // Path for "mail/<recipient>/<0000n>"
        snprintf(path, sizeof path, "%s/%s/%05d", MAIL, argv[1], n);
        if (stat(path, &statbuf) != 0) {
          out = fopen(path, "w");
          if (out != NULL) {
            while (getline(&line, &size, stdin) != -1) {
              write = fwrite(line, 1, strlen(line), out);
              if (write != strlen(line)) {
                fprintf(stderr, "%s", "Error writing to file.\n");
                fclose(out);
                out = NULL;
                free(line);
                line = NULL;
                exit(1);
              }
              free(line);
              line = NULL;
            }
            free(line);
            line = NULL;
            break;
          }
          else {
            fprintf(stderr, "%s", "Error writing to file.\n");
            exit(1);
          }
          fclose(out);
          out = NULL;
        }
      }
      if (n > 99999) {
        fprintf(stderr, "%s", "Mailbox is already full.\n");
        exit(1);
      }
    }
    else {
      fprintf(stderr, "Invalid recipient <%s>.\n", argv[1]);
      exit(1);
    }
  }
  else {
    usage();
    exit(1);
  }

  exit(0);
}